import { NextRequest, NextResponse } from "next/server";
import crypto from "crypto";
import { prisma } from "@/lib/prisma/client";
import { assertEnv } from "@/lib/env";

export async function POST(req: NextRequest) {
  try {
    const body = await req.text();
    const signature = req.headers.get("x-razorpay-signature");

    if (!signature) {
      return NextResponse.json({ error: "Missing signature" }, { status: 400 });
    }

    // Fail fast — never use an empty secret (would accept any forged payload)
    const secret = assertEnv('RAZORPAY_WEBHOOK_SECRET');

    const expectedSignature = crypto
      .createHmac("sha256", secret)
      .update(body)
      .digest("hex");

    if (expectedSignature !== signature) {
      return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
    }

    const event = JSON.parse(body);

    if (event.event === "payment.captured") {
      const paymentData = event.payload.payment.entity;
      const orderId = paymentData.notes?.orderId;
      
      if (!orderId) {
         return NextResponse.json({ error: "No orderId found in payment notes" }, { status: 400 });
      }

      await prisma.$transaction(async (tx) => {
        // Record the payment
        await tx.payment.create({
          data: {
            orderId,
            provider: "RAZORPAY",
            providerPaymentId: paymentData.id,
            providerOrderId: paymentData.order_id,
            amount: Number(paymentData.amount) / 100,
            currency: paymentData.currency,
            status: "PAID",
            method: paymentData.method,
            paidAt: new Date(paymentData.created_at * 1000),
            metadata: paymentData,
          }
        });

        // Update the order status
        await tx.order.update({
          where: { id: orderId },
          data: { status: "PROCESSING" }
        });
      });
    }

    return NextResponse.json({ status: "ok" });
  } catch (error: any) {
    console.error("Razorpay webhook error:", error);
    return NextResponse.json({ error: "Webhook handler failed" }, { status: 500 });
  }
}
