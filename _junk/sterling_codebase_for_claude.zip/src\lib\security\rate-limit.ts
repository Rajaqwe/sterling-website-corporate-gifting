// Simple in-memory rate limiter for Server Actions
// Note: In a real distributed production environment (e.g. Vercel), 
// this should be backed by Redis (e.g. @upstash/ratelimit) or a database.

const rateLimitCache = new Map<string, { count: number, resetTime: number }>();

export async function rateLimit(identifier: string, limit: number = 5, windowMs: number = 60000) {
  const now = Date.now();
  const record = rateLimitCache.get(identifier);

  // Cleanup old records occasionally (every 100 requests)
  if (Math.random() < 0.01) {
    rateLimitCache.forEach((value, key) => {
      if (value.resetTime < now) {
        rateLimitCache.delete(key);
      }
    });
  }

  if (!record || record.resetTime < now) {
    rateLimitCache.set(identifier, { count: 1, resetTime: now + windowMs });
    return { success: true };
  }

  if (record.count >= limit) {
    return { success: false, resetTime: record.resetTime };
  }

  record.count += 1;
  return { success: true };
}
