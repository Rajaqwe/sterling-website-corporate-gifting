import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Users, Building2 } from "lucide-react";
import { prisma } from "@/lib/prisma/client";
import { AdminSearchInput } from "@/components/admin/AdminSearchInput";
import { AdminPagination } from "@/components/admin/AdminPagination";

export default async function AdminCustomers(props: { searchParams: Promise<{ page?: string, q?: string }> }) {
  const searchParams = await props.searchParams;
  const page = Number(searchParams.page) || 1;
  const q = searchParams.q || "";
  const take = 10;
  const skip = (page - 1) * take;

  const where = q ? {
    OR: [
      { fullName: { contains: q, mode: 'insensitive' as const } },
      { email: { contains: q, mode: 'insensitive' as const } },
      { companyMembers: { some: { company: { name: { contains: q, mode: 'insensitive' as const } } } } },
    ]
  } : {};

  const [users, totalUsers] = await Promise.all([
    prisma.user.findMany({
      where,
      include: {
        companyMembers: {
          include: { company: true }
        }
      },
      orderBy: { createdAt: 'desc' },
      skip,
      take,
    }),
    prisma.user.count({ where })
  ]);

  const totalPages = Math.ceil(totalUsers / take);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Clients & Users</h1>
          <p className="mt-2 text-slate-500">Manage corporate accounts and individual users.</p>
        </div>
      </div>

      <div className="flex items-center gap-4 bg-background p-4 border rounded-md shadow-sm">
        <AdminSearchInput placeholder="Search customers by name, email, or company..." />
      </div>

      <div className="border border-slate-200 rounded-md bg-background overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Client Name</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Company</TableHead>
              <TableHead>Role</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Joined</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {users.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="h-64 text-center">
                  <div className="flex flex-col items-center justify-center space-y-3">
                    <Users className="h-12 w-12 text-slate-300" />
                    <h3 className="text-lg font-medium text-slate-900">No clients found</h3>
                    <p className="text-slate-500 max-w-sm text-center">There are currently no active users matching your search.</p>
                  </div>
                </TableCell>
              </TableRow>
            ) : (
              users.map((user) => (
                <TableRow key={user.id}>
                  <TableCell className="font-medium text-slate-900">
                    {user.fullName || 'N/A'}
                  </TableCell>
                  <TableCell>{user.email}</TableCell>
                  <TableCell>
                    {user.companyMembers.length > 0 ? (
                      <div className="flex items-center text-sm text-slate-600">
                        <Building2 className="mr-2 h-4 w-4 text-slate-400" />
                        {user.companyMembers[0].company.name}
                      </div>
                    ) : (
                      <span className="text-slate-400 italic">No company</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <Badge variant={user.role === 'ADMIN' ? 'default' : 'secondary'}>
                      {user.role}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant={user.isActive ? 'default' : 'destructive'} className={user.isActive ? "bg-green-100 text-green-800 hover:bg-green-100" : ""}>
                      {user.isActive ? 'Active' : 'Inactive'}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-sm text-slate-500">
                    {user.createdAt.toLocaleDateString()}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      <AdminPagination totalPages={totalPages} currentPage={page} />
    </div>
  );
}
