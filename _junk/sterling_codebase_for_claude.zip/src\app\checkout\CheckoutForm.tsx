"use client";

import { useState } from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { ShieldCheck, Building, CheckCircle2, Lock } from "lucide-react";
import { toast } from "sonner";
import { createOrderFromQuote } from "@/app/actions/orders";
import { formatINR } from "@/lib/currency";
import Script from "next/script";

export function CheckoutForm({ quote }: { quote: any }) {
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState("po");

  const itemsTotal = quote.items.reduce((acc: number, item: any) => acc + Number(item.totalPrice), 0);
  const totalQuantity = quote.items.reduce((acc: number, item: any) => acc + item.quantity, 0);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsProcessing(true);

    try {
      const formData = new FormData(e.currentTarget);
      const shippingData = {
        companyName: formData.get("companyName") as string,
        fullName: formData.get("fullName") as string,
        workEmail: formData.get("workEmail") as string,
        phone: formData.get("phone") as string,
        addressLine1: formData.get("addressLine1") as string,
        city: formData.get("city") as string,
        state: formData.get("state") as string,
        postalCode: formData.get("postalCode") as string,
      };

      // 1. Create DB Order
      const orderRes = await createOrderFromQuote(quote.id, shippingData);
      
      if (!orderRes.success || !orderRes.orderId) {
        toast.error(orderRes.error || "Failed to create order");
        setIsProcessing(false);
        return;
      }

      if (paymentMethod === "po") {
        // Just redirect to order success page
        toast.success("Order Created via PO!");
        window.location.href = `/dashboard/orders/${orderRes.orderId}`;
        return;
      }

      // 2. Create Razorpay Order
      const rpRes = await fetch("/api/checkout/razorpay", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ orderId: orderRes.orderId }),
      });

      const rpData = await rpRes.json();

      if (!rpRes.ok) {
        toast.error(rpData.error || "Failed to initialize payment");
        setIsProcessing(false);
        return;
      }

      // 3. Open Razorpay Widget
      const options = {
        key: rpData.key_id,
        amount: rpData.amount,
        currency: rpData.currency,
        name: "Sterling Corporate Gifting",
        description: `Order Payment`,
        order_id: rpData.id,
        handler: function (response: any) {
          toast.success("Payment Successful!");
          window.location.href = `/dashboard/orders/${orderRes.orderId}`;
        },
        prefill: {
          name: shippingData.fullName,
          email: shippingData.workEmail,
          contact: shippingData.phone,
        },
        theme: {
          color: "#1e293b", // primary color
        },
      };

      const rzp1 = new (window as any).Razorpay(options);
      rzp1.on("payment.failed", function (response: any) {
        toast.error(`Payment failed: ${response.error.description}`);
        setIsProcessing(false);
      });
      rzp1.open();
      
    } catch (error) {
      console.error(error);
      toast.error("An unexpected error occurred during checkout");
      setIsProcessing(false);
    }
  };

  return (
    <>
      <Script src="https://checkout.razorpay.com/v1/checkout.js" />
      <div className="grid md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-6">
          <form id="checkout-form" onSubmit={handleSubmit} className="space-y-6">
            <Card className="border-border/60 shadow-xs">
              <CardHeader className="bg-secondary/20 pb-4 border-b border-border/40">
                <CardTitle className="flex items-center gap-2 font-serif"><Building className="h-5 w-5 text-accent" /> Delivery & Shipping</CardTitle>
                <CardDescription>Enter the primary shipping destination for this bulk order.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4 pt-6">
                <div className="space-y-2">
                  <Label>Company Name *</Label>
                  <Input defaultValue={quote.companyName} name="companyName" required className="bg-secondary/10" />
                </div>
                <div className="space-y-2">
                  <Label>Contact Name *</Label>
                  <Input defaultValue={quote.fullName} name="fullName" required className="bg-secondary/10" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Email *</Label>
                    <Input defaultValue={quote.workEmail} name="workEmail" type="email" required className="bg-secondary/10" />
                  </div>
                  <div className="space-y-2">
                    <Label>Phone *</Label>
                    <Input defaultValue={quote.phone} name="phone" type="tel" required className="bg-secondary/10" />
                  </div>
                </div>
                <div className="space-y-2 pt-4 border-t border-border/40">
                  <Label>Address Line 1 *</Label>
                  <Input placeholder="Building, Street, Area" name="addressLine1" required className="bg-secondary/10" />
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="col-span-1 space-y-2">
                    <Label>City *</Label>
                    <Input name="city" required className="bg-secondary/10" />
                  </div>
                  <div className="col-span-1 space-y-2">
                    <Label>State *</Label>
                    <Input name="state" required className="bg-secondary/10" />
                  </div>
                  <div className="col-span-1 space-y-2">
                    <Label>ZIP Code *</Label>
                    <Input name="postalCode" required className="bg-secondary/10" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border/60 shadow-xs">
              <CardHeader className="bg-secondary/20 pb-4 border-b border-border/40">
                <CardTitle className="flex items-center gap-2 font-serif"><ShieldCheck className="h-5 w-5 text-accent" /> Payment Method</CardTitle>
                <CardDescription>Select how you would like to settle this invoice.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4 pt-6">
                <label className={`flex items-start p-4 border rounded-xl cursor-pointer transition-all ${paymentMethod === 'po' ? 'border-accent bg-accent/5 ring-1 ring-accent/30' : 'border-border/60 hover:bg-secondary/20'}`}>
                  <input type="radio" name="payment" value="po" checked={paymentMethod === 'po'} onChange={() => setPaymentMethod('po')} className="mt-1 mr-4 accent-accent" />
                  <div>
                    <div className="font-semibold text-primary">Corporate Purchase Order (PO) / Bank Transfer</div>
                    <div className="text-xs text-muted-foreground mt-1">Generate an invoice and pay via NEFT/RTGS within Net 30 terms.</div>
                  </div>
                </label>
                <label className={`flex items-start p-4 border rounded-xl cursor-pointer transition-all ${paymentMethod === 'card' ? 'border-accent bg-accent/5 ring-1 ring-accent/30' : 'border-border/60 hover:bg-secondary/20'}`}>
                  <input type="radio" name="payment" value="card" checked={paymentMethod === 'card'} onChange={() => setPaymentMethod('card')} className="mt-1 mr-4 accent-accent" />
                  <div>
                    <div className="font-semibold text-primary">Credit Card / UPI (Razorpay)</div>
                    <div className="text-xs text-muted-foreground mt-1">Pay instantly online using a company card or UPI.</div>
                  </div>
                </label>
              </CardContent>
            </Card>
          </form>
        </div>

        <div className="md:col-span-1">
          <Card className="sticky top-24 border-border/60 shadow-lg">
            <CardHeader className="pb-4">
              <CardTitle className="font-serif">Order Summary</CardTitle>
              <CardDescription className="text-xs">Based on approved quote <span className="font-semibold text-primary">{quote.quoteNumber}</span></CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              
              <div className="bg-secondary/20 rounded-lg p-3 space-y-3 mb-4 max-h-64 overflow-y-auto">
                {quote.items.map((item: any, idx: number) => (
                  <div key={idx} className="flex justify-between text-xs pb-3 border-b border-border/50 last:border-0 last:pb-0">
                    <div className="flex-1 pr-4">
                      <span className="font-semibold text-foreground block truncate">{item.product?.name || `Product #${item.productId}`}</span>
                      <span className="text-muted-foreground">Qty: {item.quantity}</span>
                    </div>
                    <span className="font-medium text-right">{formatINR(Number(item.totalPrice))}</span>
                  </div>
                ))}
              </div>

              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Items ({totalQuantity} units)</span>
                <span className="font-medium">{formatINR(itemsTotal)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Shipping</span>
                <span className="font-medium">TBD</span>
              </div>
              <Separator className="my-2" />
              <div className="flex justify-between items-end">
                <span className="font-bold text-foreground">Total</span>
                <div className="text-right">
                  <span className="font-bold text-xl text-primary block">{formatINR(itemsTotal)}</span>
                  <span className="text-[10px] text-muted-foreground">Plus applicable GST</span>
                </div>
              </div>
              
              <div className="pt-4 space-y-2">
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <CheckCircle2 className="h-3 w-3 text-emerald-500" /> GST Invoice provided
                </div>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Lock className="h-3 w-3 text-emerald-500" /> Secure 256-bit encryption
                </div>
              </div>
            </CardContent>
            
            <div className="p-6 pt-0">
              <Button 
                type="submit" 
                form="checkout-form" 
                disabled={isProcessing}
                className="w-full bg-accent text-primary hover:bg-gold-hover h-12 font-bold shadow-md text-sm transition-all"
              >
                {isProcessing ? (
                  <>
                    <span className="h-4 w-4 animate-spin rounded-full border-2 border-primary/50 border-t-primary mr-2" />
                    Processing...
                  </>
                ) : (
                  <>Confirm Corporate Order</>
                )}
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </>
  );
}
