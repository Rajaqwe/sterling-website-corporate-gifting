"use client";

import { useState } from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { createOrderFromQuote } from "@/app/actions/orders";
import Script from "next/script";

interface CheckoutFormProps {
  quoteId: string;
  defaultValues: {
    companyName: string;
    fullName: string;
    workEmail: string;
    phone: string;
  };
}

export function CheckoutForm({ quoteId, defaultValues }: CheckoutFormProps) {
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsProcessing(true);

    try {
      const formData = new FormData(e.currentTarget);
      const shippingData = {
        companyName: formData.get("companyName") as string,
        fullName: formData.get("fullName") as string,
        workEmail: formData.get("workEmail") as string,
        phone: formData.get("phone") as string,
        addressLine1: formData.get("addressLine1") as string,
        city: formData.get("city") as string,
        state: formData.get("state") as string,
        postalCode: formData.get("postalCode") as string,
      };

      // 1. Create DB Order
      const orderRes = await createOrderFromQuote(quoteId, shippingData);
      
      if (!orderRes.success || !orderRes.orderId) {
        toast.error(orderRes.error || "Failed to create order");
        setIsProcessing(false);
        return;
      }

      // 2. Create Razorpay Order
      const rpRes = await fetch("/api/checkout/razorpay", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ orderId: orderRes.orderId }),
      });

      const rpData = await rpRes.json();

      if (!rpRes.ok) {
        toast.error(rpData.error || "Failed to initialize payment");
        setIsProcessing(false);
        return;
      }

      // 3. Open Razorpay Widget
      const options = {
        key: rpData.key_id,
        amount: rpData.amount,
        currency: rpData.currency,
        name: "Sterling Corporate Gifting",
        description: `Order Payment`,
        order_id: rpData.id,
        handler: function (response: any) {
          toast.success("Payment Successful!");
          window.location.href = `/dashboard/orders/${orderRes.orderId}`;
        },
        prefill: {
          name: shippingData.fullName,
          email: shippingData.workEmail,
          contact: shippingData.phone,
        },
        theme: {
          color: "#0f172a", // primary color
        },
      };

      const rzp1 = new (window as any).Razorpay(options);
      rzp1.on("payment.failed", function (response: any) {
        toast.error(`Payment failed: ${response.error.description}`);
      });
      rzp1.open();
      
    } catch (error) {
      console.error(error);
      toast.error("An unexpected error occurred during checkout");
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <>
      <Script src="https://checkout.razorpay.com/v1/checkout.js" />
      <form id="checkout-form" onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label>Company Name</Label>
          <Input defaultValue={defaultValues.companyName} name="companyName" required />
        </div>
        <div className="space-y-2">
          <Label>Contact Name</Label>
          <Input defaultValue={defaultValues.fullName} name="fullName" required />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Email</Label>
            <Input defaultValue={defaultValues.workEmail} name="workEmail" type="email" required />
          </div>
          <div className="space-y-2">
            <Label>Phone</Label>
            <Input defaultValue={defaultValues.phone} name="phone" type="tel" required />
          </div>
        </div>
        <div className="space-y-2">
          <Label>Address Line 1</Label>
          <Input placeholder="Building, Street" name="addressLine1" required />
        </div>
        <div className="grid grid-cols-3 gap-4">
          <div className="col-span-1 space-y-2">
            <Label>City</Label>
            <Input name="city" required />
          </div>
          <div className="col-span-1 space-y-2">
            <Label>State</Label>
            <Input name="state" required />
          </div>
          <div className="col-span-1 space-y-2">
            <Label>ZIP Code</Label>
            <Input name="postalCode" required />
          </div>
        </div>
      </form>
      
      {/* Hidden button so page.tsx can trigger the form */}
      <Button 
        type="submit" 
        form="checkout-form" 
        disabled={isProcessing} 
        id="submit-checkout" 
        className="hidden"
      >
        Confirm
      </Button>
    </>
  );
}
