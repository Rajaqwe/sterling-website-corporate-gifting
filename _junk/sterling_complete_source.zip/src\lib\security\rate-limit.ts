// Distributed rate limiter for Server Actions and Webhooks
// Falls back to in-memory caching if Redis environment variables are not configured

import { Ratelimit } from "@upstash/ratelimit";
import { Redis } from "@upstash/redis";

// --- In-memory Fallback (for local development) ---
const rateLimitCache = new Map<string, { count: number, resetTime: number }>();

function memoryRateLimit(identifier: string, limit: number, windowMs: number) {
  const now = Date.now();
  const record = rateLimitCache.get(identifier);

  // Cleanup old records occasionally (every 100 requests)
  if (Math.random() < 0.01) {
    rateLimitCache.forEach((value, key) => {
      if (value.resetTime < now) {
        rateLimitCache.delete(key);
      }
    });
  }

  if (!record || record.resetTime < now) {
    rateLimitCache.set(identifier, { count: 1, resetTime: now + windowMs });
    return { success: true };
  }

  if (record.count >= limit) {
    return { success: false, resetTime: record.resetTime };
  }

  record.count += 1;
  return { success: true };
}

// --- Redis Client Initialization ---
let redisClient: Redis | null = null;
let ratelimitClient: Ratelimit | null = null;

if (process.env.UPSTASH_REDIS_REST_URL && process.env.UPSTASH_REDIS_REST_TOKEN) {
  try {
    redisClient = new Redis({
      url: process.env.UPSTASH_REDIS_REST_URL,
      token: process.env.UPSTASH_REDIS_REST_TOKEN,
    });
    
    // Default config, actual window is handled per-request when possible, 
    // but Upstash's interface binds the window to the client instance.
    // For this generic wrapper, we'll use a sliding window of 60s as a baseline.
    ratelimitClient = new Ratelimit({
      redis: redisClient,
      limiter: Ratelimit.slidingWindow(5, "60 s"),
      analytics: true,
    });
  } catch (error) {
    console.error("Failed to initialize Upstash Redis:", error);
  }
}

/**
 * Validates rate limit. Uses Upstash Redis if configured, otherwise falls back to memory.
 * Note: When using Redis, the limit and windowMs arguments are currently overridden
 * by the global client configuration (5 requests / 60 seconds) due to Upstash API design,
 * but the arguments are kept for the memory fallback.
 */
export async function rateLimit(identifier: string, limit: number = 5, windowMs: number = 60000) {
  if (ratelimitClient) {
    try {
      const { success, reset } = await ratelimitClient.limit(identifier);
      return { success, resetTime: reset };
    } catch (error) {
      console.error("Redis rate limit failed, falling back to memory:", error);
      return memoryRateLimit(identifier, limit, windowMs);
    }
  }

  // Fallback
  return memoryRateLimit(identifier, limit, windowMs);
}
